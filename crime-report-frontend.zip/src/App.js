import React from "react";
import Page from "./pages/Page";

const App = () => {
  return (
    <>
    <Page />
    </>
  );
};

export default App;
